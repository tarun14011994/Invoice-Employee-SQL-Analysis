-- SQL Practice Queries (50+) for 10,000-row datasets

-- Author: Tarun Kumar

-- Tables: Employees(EmployeeID, Name, Department, City, Salary, JoiningDate)

--         Invoices(InvoiceID, VendorName, Amount, City, InvoiceDate, Status)



SELECT * FROM Employees;

SELECT * FROM Invoices;

SELECT Name, Department, Salary FROM Employees WHERE Department='IT';

SELECT InvoiceID, VendorName, Amount FROM Invoices WHERE Status='Overdue';

SELECT * FROM Employees WHERE City <> 'Bangalore' ORDER BY Salary DESC;

SELECT * FROM Invoices WHERE Amount > 100000 ORDER BY Amount DESC;

SELECT * FROM Employees WHERE Department IN ('Finance','Sales');

SELECT * FROM Employees WHERE Department='Marketing' AND Salary>55000 AND City<>'Delhi';

SELECT * FROM Invoices WHERE VendorName IN ('Infosys','IBM') AND Amount>100000;

SELECT * FROM Employees WHERE JoiningDate BETWEEN '2020-01-01' AND '2024-12-31';

SELECT Department, COUNT(*) AS EmpCount FROM Employees GROUP BY Department;

SELECT Department, ROUND(AVG(Salary),2) AS AvgSalary FROM Employees GROUP BY Department;

SELECT City, SUM(Amount) AS TotalInvoiceAmount FROM Invoices GROUP BY City;

SELECT VendorName, COUNT(*) AS InvoiceCount, SUM(Amount) AS Total FROM Invoices GROUP BY VendorName;

SELECT Status, COUNT(*) AS Cnt FROM Invoices GROUP BY Status;

SELECT MAX(Salary) AS MaxSalary, MIN(Salary) AS MinSalary FROM Employees;

SELECT VendorName FROM Invoices GROUP BY VendorName HAVING SUM(Amount) > 2000000;

SELECT e.Name, e.Department, e.City, i.VendorName, i.Amount, i.Status
FROM Employees e
JOIN Invoices i ON e.City = i.City;

SELECT e.Name, e.City, i.Amount
FROM Employees e
LEFT JOIN Invoices i ON e.City = i.City;

SELECT i.VendorName, i.City, e.EmployeeID
FROM Invoices i
RIGHT JOIN Employees e ON e.City = i.City;

SELECT * FROM Employees WHERE Name LIKE 'A%' OR Name LIKE 'S%';

SELECT * FROM Invoices WHERE City IN ('Mumbai','Delhi','Bangalore') AND Status <> 'Paid';

SELECT * FROM Employees WHERE Salary BETWEEN 70000 AND 90000;

SELECT * FROM Employees WHERE Department NOT IN ('Admin','Procurement');

SELECT *
FROM Employees
WHERE Salary > (SELECT AVG(Salary) FROM Employees);

SELECT VendorName, Amount
FROM Invoices
WHERE Amount > (SELECT AVG(Amount) FROM Invoices WHERE Status='Paid');

SELECT Name, Salary
FROM Employees
WHERE (Department, Salary) IN (
  SELECT Department, MAX(Salary) FROM Employees GROUP BY Department
);

-- Top 10 highest paid employees per department (portable approach)
SELECT e1.*
FROM Employees e1
JOIN (
  SELECT Department, MAX(Salary) AS MaxSalary
  FROM Employees
  GROUP BY Department
) t ON e1.Department = t.Department AND e1.Salary = t.MaxSalary
ORDER BY e1.Department, e1.Salary DESC;

INSERT INTO Employees (EmployeeID, Name, Department, City, Salary, JoiningDate) VALUES (20001,'Tarun Kumar','Finance','Kolkata',65000,'2023-05-01');

UPDATE Employees SET Salary = Salary + 5000 WHERE Department='Finance';

DELETE FROM Employees WHERE EmployeeID = 123;

SELECT e.City, COUNT(DISTINCT e.EmployeeID) AS Employees, COUNT(i.InvoiceID) AS Invoices,
       SUM(i.Amount) AS TotalAmount
FROM Employees e
LEFT JOIN Invoices i ON e.City = i.City
GROUP BY e.City
ORDER BY TotalAmount DESC;

SELECT VendorName, ROUND(AVG(Amount),2) AS AvgAmount
FROM Invoices
GROUP BY VendorName
ORDER BY AvgAmount DESC
LIMIT 10;

SELECT City, Status, COUNT(*) AS Cnt, SUM(Amount) AS Total
FROM Invoices
GROUP BY City, Status
ORDER BY City, Total DESC;

-- Duplicate invoice check by (VendorName, Amount, InvoiceDate)
SELECT VendorName, Amount, InvoiceDate, COUNT(*) AS DupCount
FROM Invoices
GROUP BY VendorName, Amount, InvoiceDate
HAVING COUNT(*) > 1;

-- Employee salary distribution by city
SELECT City,
       SUM(CASE WHEN Salary < 40000 THEN 1 ELSE 0 END) AS LT_40k,
       SUM(CASE WHEN Salary BETWEEN 40000 AND 60000 THEN 1 ELSE 0 END) AS BTW_40k_60k,
       SUM(CASE WHEN Salary BETWEEN 60001 AND 80000 THEN 1 ELSE 0 END) AS BTW_60k_80k,
       SUM(CASE WHEN Salary > 80000 THEN 1 ELSE 0 END) AS GT_80k
FROM Employees
GROUP BY City;

-- Vendor with maximum pending invoice count
SELECT VendorName, COUNT(*) AS PendingCount
FROM Invoices
WHERE Status='Pending'
GROUP BY VendorName
ORDER BY PendingCount DESC
LIMIT 5;

-- Monthly invoice totals (YYYY-MM)
SELECT strftime('%Y-%m', InvoiceDate) AS Month, SUM(Amount) AS Total
FROM Invoices
GROUP BY strftime('%Y-%m', InvoiceDate)
ORDER BY Month;

-- Employees joined per year
SELECT strftime('%Y', JoiningDate) AS Year, COUNT(*) AS Joined
FROM Employees
GROUP BY strftime('%Y', JoiningDate)
ORDER BY Year;

-- Cities with no overdue invoices (anti-join pattern)
SELECT c.City
FROM (SELECT DISTINCT City FROM Employees) c
LEFT JOIN (
  SELECT DISTINCT City FROM Invoices WHERE Status='Overdue'
) o ON c.City = o.City
WHERE o.City IS NULL;

-- Top 10 cities by average salary
SELECT City, ROUND(AVG(Salary),2) AS AvgSalary
FROM Employees
GROUP BY City
ORDER BY AvgSalary DESC
LIMIT 10;

-- Median-like approximation using percentiles (engine specific, sample portable note)
-- For real median, use engine's percentile/distribution functions (e.g., PERCENTILE_CONT in Postgres).

-- TRUNCATE vs DELETE (notes)
-- TRUNCATE removes all rows quickly; usually cannot be rolled back and resets identity (engine dependent).
-- DELETE removes rows one-by-one; can be filtered with WHERE and commonly can be rolled back in a transaction.