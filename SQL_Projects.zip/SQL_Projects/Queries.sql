-- SQL Practice Queries by Tarun Kumar

-- 1. Show all employees
SELECT * FROM Employees;

-- 2. Show employees who belong to HR or Sales department
SELECT * FROM Employees WHERE Department IN ('HR','Sales');

-- 3. Display employees who are not from Bangalore
SELECT * FROM Employees WHERE City <> 'Bangalore';

-- 4. Find employees in Marketing earning above 55,000 but living outside Delhi
SELECT * FROM Employees WHERE Department='Marketing' AND Salary>55000 AND City<>'Delhi';

-- 5. List top 5 highest paid employees
SELECT * FROM Employees ORDER BY Salary DESC LIMIT 5;

-- 6. Insert a new employee
INSERT INTO Employees (EmployeeID, Name, Department, City, Salary, JoiningDate)
VALUES (101,'Tarun Kumar','Finance','Kolkata',60000,'2023-05-01');

-- 7. Update salary of employee ID 10 to 80,000
UPDATE Employees SET Salary=80000 WHERE EmployeeID=10;

-- 8. Delete employee who has ID=20
DELETE FROM Employees WHERE EmployeeID=20;

-- 9. Show total salary by department
SELECT Department, SUM(Salary) as TotalSalary FROM Employees GROUP BY Department;

-- 10. Show average salary of employees in IT department
SELECT AVG(Salary) as Avg_IT_Salary FROM Employees WHERE Department='IT';

-- 11. Show employees who joined after 2020
SELECT * FROM Employees WHERE JoiningDate > '2020-01-01';

-- 12. Show all invoices greater than 50,000
SELECT * FROM Invoices WHERE Amount > 50000;

-- 13. Show invoices which are overdue
SELECT * FROM Invoices WHERE Status='Overdue';

-- 14. Count number of invoices by each vendor
SELECT VendorName, COUNT(*) as InvoiceCount FROM Invoices GROUP BY VendorName;

-- 15. Show total amount paid by city
SELECT City, SUM(Amount) as TotalAmount FROM Invoices GROUP BY City;

-- 16. Find vendors who have pending invoices
SELECT DISTINCT VendorName FROM Invoices WHERE Status='Pending';

-- 17. Show invoices from Infosys or IBM with amount above 100,000
SELECT * FROM Invoices WHERE VendorName IN ('Infosys','IBM') AND Amount>100000;

-- 18. Join Employees and Invoices by City
SELECT e.Name, e.Department, i.VendorName, i.Amount, e.City
FROM Employees e
JOIN Invoices i ON e.City=i.City;

-- 19. Show employees along with invoice amount if available (LEFT JOIN)
SELECT e.Name, e.City, i.Amount
FROM Employees e
LEFT JOIN Invoices i ON e.City=i.City;

-- 20. Difference between TRUNCATE and DELETE (comment)
-- TRUNCATE removes all rows quickly without logging individual row deletions.
-- DELETE removes rows one by one and can be rolled back if within a transaction.
