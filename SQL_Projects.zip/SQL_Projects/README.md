# SQL Practice Projects

This repository contains SQL queries and datasets created for practicing database management and data analysis.

## Datasets
- Employees.csv – Employee records dataset (50 records)
- Invoices.csv – Vendor invoice dataset (50 records)

## SQL Queries
- Basic SELECT, WHERE, ORDER BY
- INSERT, UPDATE, DELETE
- JOINS (INNER, LEFT, RIGHT)
- Aggregate Functions (SUM, COUNT, AVG)
- Subqueries
- TRUNCATE vs DELETE

## Author
Tarun Kumar
LinkedIn: https://www.linkedin.com/in/tarun-kumar-86bab9142/
